import Link from 'next/link';

export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="border-t border-gray-100 bg-adamas-black text-gray-300">
      <div className="container-adamas grid grid-cols-1 gap-8 py-12 sm:grid-cols-2 lg:grid-cols-4">
        <div>
          <p className="font-display text-lg font-bold text-white">SK ADAMAS</p>
          <p className="mt-2 text-sm text-gray-400">
            Спортивний клуб з тхеквондо та кікбоксингу ISKA в Івано-Франківську та області.
          </p>
        </div>

        <div>
          <p className="mb-3 text-sm font-semibold text-white">Клуб</p>
          <ul className="space-y-2 text-sm">
            <li><Link href="/directions" className="hover:text-white">Напрямки</Link></li>
            <li><Link href="/locations" className="hover:text-white">Філії</Link></li>
            <li><Link href="/trainers" className="hover:text-white">Тренери</Link></li>
            <li><Link href="/schedule" className="hover:text-white">Розклад</Link></li>
            <li><Link href="/achievements" className="hover:text-white">Досягнення</Link></li>
          </ul>
        </div>

        <div>
          <p className="mb-3 text-sm font-semibold text-white">Контакти</p>
          <ul className="space-y-2 text-sm">
            <li><Link href="/contact" className="hover:text-white">Контакти</Link></li>
            <li>
              <a href="https://www.instagram.com/adamas_ua" target="_blank" rel="noopener noreferrer" className="hover:text-white">
                Instagram
              </a>
            </li>
          </ul>
        </div>

        <div>
          <p className="mb-3 text-sm font-semibold text-white">Правова інформація</p>
          <ul className="space-y-2 text-sm">
            <li><Link href="/privacy" className="hover:text-white">Політика конфіденційності</Link></li>
            <li><Link href="/terms" className="hover:text-white">Умови використання</Link></li>
          </ul>
        </div>
      </div>

      <div className="border-t border-white/10 py-4 text-center text-xs text-gray-500">
        © {year} SK ADAMAS. Всі права захищені.
      </div>
    </footer>
  );
}
