'use client';

import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useState } from 'react';
import Link from 'next/link';

const clientSchema = z.object({
  childName: z.string().trim().min(2, "Введіть ім'я та прізвище"),
  age: z.coerce.number().int().min(3, 'Вкажіть вік').max(99),
  contactName: z.string().trim().min(2, "Введіть ім'я контактної особи"),
  contactPhone: z.string().trim().min(9, 'Введіть номер телефону'),
  directionId: z.string().optional(),
  locationId: z.string().optional(),
  comment: z.string().optional(),
  consentPolicy: z.literal(true, { errorMap: () => ({ message: 'Потрібна згода з політикою конфіденційності' }) })
});

type FormValues = z.infer<typeof clientSchema>;

export default function SignupForm({
  locations,
  directions,
  defaultLocationId,
  defaultDirectionId
}: {
  locations: { id: string; name: string }[];
  directions: { id: string; name: string }[];
  defaultLocationId?: string;
  defaultDirectionId?: string;
}) {
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  const [serverError, setServerError] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    watch,
    formState: { errors }
  } = useForm<FormValues>({
    resolver: zodResolver(clientSchema),
    defaultValues: { locationId: defaultLocationId, directionId: defaultDirectionId }
  });

  const age = watch('age');
  const isMinor = !age || age < 18;

  async function onSubmit(values: FormValues) {
    setStatus('submitting');
    setServerError(null);
    try {
      const res = await fetch('/api/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(values)
      });
      const json = await res.json();
      if (!res.ok) {
        setServerError(json.error || 'Не вдалося відправити заявку.');
        setStatus('error');
        return;
      }
      setStatus('success');
    } catch {
      setServerError('Проблема з мережею. Перевірте з’єднання та спробуйте ще раз.');
      setStatus('error');
    }
  }

  if (status === 'success') {
    return (
      <div className="card mt-8 text-center">
        <p className="font-display text-xl font-semibold">Дякуємо за заявку!</p>
        <p className="mt-2 text-gray-600">Ми зв'яжемося з вами найближчим часом для підтвердження запису.</p>
        <Link href="/" className="btn-secondary mt-4 inline-flex">На головну</Link>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="mt-8 space-y-5" noValidate>
      <div>
        <label htmlFor="childName" className="block text-sm font-medium">Ім'я та прізвище учасника *</label>
        <input id="childName" {...register('childName')} className="mt-1 w-full rounded-md border border-gray-300 px-3 py-2" />
        {errors.childName && <p className="mt-1 text-sm text-red-600">{errors.childName.message}</p>}
      </div>

      <div>
        <label htmlFor="age" className="block text-sm font-medium">Вік *</label>
        <input id="age" type="number" {...register('age')} className="mt-1 w-32 rounded-md border border-gray-300 px-3 py-2" />
        {errors.age && <p className="mt-1 text-sm text-red-600">{errors.age.message}</p>}
      </div>

      {isMinor && (
        <p className="rounded-md bg-amber-50 px-4 py-3 text-sm text-amber-800">
          Учасник неповнолітній — контактні дані нижче мають належати батькам або законному представнику.
        </p>
      )}

      <div>
        <label htmlFor="contactName" className="block text-sm font-medium">
          {isMinor ? "Ім'я батька/матері або представника *" : "Ваше ім'я *"}
        </label>
        <input id="contactName" {...register('contactName')} className="mt-1 w-full rounded-md border border-gray-300 px-3 py-2" />
        {errors.contactName && <p className="mt-1 text-sm text-red-600">{errors.contactName.message}</p>}
      </div>

      <div>
        <label htmlFor="contactPhone" className="block text-sm font-medium">Телефон для зв'язку *</label>
        <input id="contactPhone" type="tel" {...register('contactPhone')} placeholder="+380 XX XXX XX XX" className="mt-1 w-full rounded-md border border-gray-300 px-3 py-2" />
        {errors.contactPhone && <p className="mt-1 text-sm text-red-600">{errors.contactPhone.message}</p>}
      </div>

      <div>
        <label htmlFor="directionId" className="block text-sm font-medium">Напрямок</label>
        <select id="directionId" {...register('directionId')} className="mt-1 w-full rounded-md border border-gray-300 px-3 py-2">
          <option value="">Оберіть напрямок</option>
          {directions.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
        </select>
      </div>

      <div>
        <label htmlFor="locationId" className="block text-sm font-medium">Філія</label>
        <select id="locationId" {...register('locationId')} className="mt-1 w-full rounded-md border border-gray-300 px-3 py-2">
          <option value="">Оберіть філію</option>
          {locations.map((l) => <option key={l.id} value={l.id}>{l.name}</option>)}
        </select>
      </div>

      <div>
        <label htmlFor="comment" className="block text-sm font-medium">Коментар</label>
        <textarea id="comment" {...register('comment')} rows={3} className="mt-1 w-full rounded-md border border-gray-300 px-3 py-2" />
      </div>

      <div className="flex items-start gap-2">
        <input id="consentPolicy" type="checkbox" {...register('consentPolicy')} className="mt-1" />
        <label htmlFor="consentPolicy" className="text-sm text-gray-600">
          Я погоджуюся з <Link href="/privacy" className="underline">Політикою конфіденційності</Link> *
        </label>
      </div>
      {errors.consentPolicy && <p className="text-sm text-red-600">{errors.consentPolicy.message}</p>}

      {status === 'error' && serverError && (
        <p className="rounded-md bg-red-50 px-4 py-3 text-sm text-red-700">{serverError}</p>
      )}

      <button type="submit" disabled={status === 'submitting'} className="btn-primary w-full disabled:opacity-60">
        {status === 'submitting' ? 'Відправка...' : 'Відправити заявку'}
      </button>
    </form>
  );
}
