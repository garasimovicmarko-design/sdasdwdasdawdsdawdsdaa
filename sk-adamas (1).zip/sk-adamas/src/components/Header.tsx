'use client';

import Link from 'next/link';
import { useState } from 'react';

const navItems = [
  { href: '/directions', label: 'Напрямки' },
  { href: '/locations', label: 'Філії' },
  { href: '/trainers', label: 'Тренери' },
  { href: '/schedule', label: 'Розклад' },
  { href: '/achievements', label: 'Досягнення' },
  { href: '/about', label: 'Про клуб' },
  { href: '/contact', label: 'Контакти' }
];

export default function Header() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 border-b border-gray-100 bg-white/95 backdrop-blur">
      <div className="container-adamas flex h-16 items-center justify-between">
        <Link href="/" className="font-display text-xl font-bold tracking-wide">
          SK ADAMAS
        </Link>

        <nav className="hidden items-center gap-6 lg:flex" aria-label="Головна навігація">
          {navItems.map((item) => (
            <Link key={item.href} href={item.href} className="text-sm font-medium text-gray-700 hover:text-adamas-red">
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="hidden lg:block">
          <Link href="/signup" className="btn-primary">
            Записатися на тренування
          </Link>
        </div>

        <button
          className="lg:hidden"
          aria-label={open ? 'Закрити меню' : 'Відкрити меню'}
          aria-expanded={open}
          onClick={() => setOpen((v) => !v)}
        >
          <span className="block h-0.5 w-6 bg-adamas-black" />
          <span className="mt-1.5 block h-0.5 w-6 bg-adamas-black" />
          <span className="mt-1.5 block h-0.5 w-6 bg-adamas-black" />
        </button>
      </div>

      {open && (
        <div className="border-t border-gray-100 bg-white lg:hidden">
          <nav className="container-adamas flex flex-col gap-1 py-3" aria-label="Мобільна навігація">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="rounded-md px-2 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"
                onClick={() => setOpen(false)}
              >
                {item.label}
              </Link>
            ))}
            <Link href="/signup" className="btn-primary mt-2 w-full" onClick={() => setOpen(false)}>
              Записатися на тренування
            </Link>
          </nav>
        </div>
      )}

      {/* Sticky mobile CTA so signup is always one tap away, per spec */}
      <Link
        href="/signup"
        className="fixed bottom-4 left-1/2 z-40 -translate-x-1/2 rounded-full bg-adamas-red px-6 py-3 text-sm font-semibold text-white shadow-lg lg:hidden"
      >
        Записатися
      </Link>
    </header>
  );
}
