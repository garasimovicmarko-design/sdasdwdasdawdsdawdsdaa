'use client';

import { useMemo, useState } from 'react';

type Signup = {
  id: string;
  childName: string;
  age: number;
  contactName: string;
  contactPhone: string;
  isMinor: boolean;
  status: string;
  internalNote: string | null;
  comment: string | null;
  createdAt: string;
  direction: { name: string } | null;
  location: { name: string } | null;
};

const statuses = ['NEW', 'CONTACTED', 'CONFIRMED', 'COMPLETED', 'CANCELLED'];

export default function AdminSignupsManager({ initialSignups }: { initialSignups: Signup[] }) {
  const [signups, setSignups] = useState<Signup[]>(initialSignups);
  const [filter, setFilter] = useState('');
  const [query, setQuery] = useState('');
  const [expanded, setExpanded] = useState<string | null>(null);

  const filtered = useMemo(() => {
    return signups.filter((s) => {
      if (filter && s.status !== filter) return false;
      if (query && !`${s.childName} ${s.contactName} ${s.contactPhone}`.toLowerCase().includes(query.toLowerCase())) return false;
      return true;
    });
  }, [signups, filter, query]);

  async function updateStatus(id: string, status: string) {
    const res = await fetch(`/api/admin/signups/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status })
    });
    if (res.ok) setSignups((prev) => prev.map((s) => (s.id === id ? { ...s, status } : s)));
  }

  async function saveNote(id: string, internalNote: string) {
    const res = await fetch(`/api/admin/signups/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ internalNote })
    });
    if (res.ok) setSignups((prev) => prev.map((s) => (s.id === id ? { ...s, internalNote } : s)));
  }

  async function remove(id: string) {
    if (!confirm('Видалити цю заявку безповоротно?')) return;
    const res = await fetch(`/api/admin/signups/${id}`, { method: 'DELETE' });
    if (res.ok) setSignups((prev) => prev.filter((s) => s.id !== id));
  }

  return (
    <div className="mt-6">
      <div className="flex flex-wrap gap-3">
        <input
          placeholder="Пошук за ім'ям або телефоном"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="rounded-md border border-gray-300 px-3 py-2 text-sm"
        />
        <select value={filter} onChange={(e) => setFilter(e.target.value)} className="rounded-md border border-gray-300 px-3 py-2 text-sm">
          <option value="">Всі статуси</option>
          {statuses.map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
      </div>

      <div className="mt-4 space-y-3">
        {filtered.map((s) => (
          <div key={s.id} className="rounded-lg border border-gray-200 p-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <p className="font-semibold">{s.childName} ({s.age}){s.isMinor && <span className="ml-2 text-xs text-amber-600">неповнолітній</span>}</p>
                <p className="text-sm text-gray-600">{s.contactName} · {s.contactPhone}</p>
                <p className="text-xs text-gray-400">{s.direction?.name || '—'} · {s.location?.name || '—'}</p>
              </div>
              <div className="flex items-center gap-2">
                <select value={s.status} onChange={(e) => updateStatus(s.id, e.target.value)} className="rounded-md border border-gray-300 px-2 py-1 text-sm">
                  {statuses.map((st) => <option key={st} value={st}>{st}</option>)}
                </select>
                <button onClick={() => setExpanded(expanded === s.id ? null : s.id)} className="text-sm text-adamas-red underline">
                  {expanded === s.id ? 'Згорнути' : 'Деталі'}
                </button>
                <button onClick={() => remove(s.id)} className="text-sm text-gray-500 underline">Видалити</button>
              </div>
            </div>

            {expanded === s.id && (
              <div className="mt-3 border-t border-gray-100 pt-3">
                {s.comment && <p className="text-sm text-gray-600">Коментар клієнта: {s.comment}</p>}
                <label className="mt-2 block text-sm font-medium">Внутрішня примітка</label>
                <textarea
                  defaultValue={s.internalNote || ''}
                  onBlur={(e) => saveNote(s.id, e.target.value)}
                  rows={2}
                  className="mt-1 w-full rounded-md border border-gray-300 px-3 py-2 text-sm"
                />
              </div>
            )}
          </div>
        ))}
        {filtered.length === 0 && <p className="py-8 text-center text-gray-400">Заявок не знайдено.</p>}
      </div>
    </div>
  );
}
