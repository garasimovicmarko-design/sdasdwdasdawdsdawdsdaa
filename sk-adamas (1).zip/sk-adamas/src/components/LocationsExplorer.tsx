'use client';

import { useMemo, useState } from 'react';
import Link from 'next/link';
import dynamic from 'next/dynamic';

const LocationsMap = dynamic(() => import('./LocationsMap'), { ssr: false });

type Direction = { id: string; slug: string; name: string };
type LocationDirection = { direction: Direction };
type Trainer = { id: string; name: string } | null;

type LocationItem = {
  id: string;
  name: string;
  address: string;
  district: string | null;
  phone: string;
  minAge: number;
  latitude: number | null;
  longitude: number | null;
  trainer: Trainer;
  trainerName: string | null;
  directions: LocationDirection[];
};

export default function LocationsExplorer({
  locations,
  directions,
  districts
}: {
  locations: LocationItem[];
  directions: Direction[];
  districts: string[];
}) {
  const [view, setView] = useState<'list' | 'map'>('list');
  const [query, setQuery] = useState('');
  const [district, setDistrict] = useState('');
  const [directionSlug, setDirectionSlug] = useState('');
  const [minAge, setMinAge] = useState('');

  const filtered = useMemo(() => {
    return locations.filter((loc) => {
      if (query && !`${loc.name} ${loc.address}`.toLowerCase().includes(query.toLowerCase())) return false;
      if (district && loc.district !== district) return false;
      if (directionSlug && !loc.directions.some((d) => d.direction.slug === directionSlug)) return false;
      if (minAge && loc.minAge > Number(minAge)) return false;
      return true;
    });
  }, [locations, query, district, directionSlug, minAge]);

  return (
    <div className="mt-8">
      <div className="flex flex-wrap items-end gap-4">
        <div className="flex-1 min-w-[200px]">
          <label htmlFor="q" className="block text-sm font-medium text-gray-700">Пошук</label>
          <input
            id="q"
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Назва або адреса"
            className="mt-1 w-full rounded-md border border-gray-300 px-3 py-2 text-sm focus:border-adamas-red focus:outline-none"
          />
        </div>

        <div>
          <label htmlFor="district" className="block text-sm font-medium text-gray-700">Район</label>
          <select
            id="district"
            value={district}
            onChange={(e) => setDistrict(e.target.value)}
            className="mt-1 rounded-md border border-gray-300 px-3 py-2 text-sm"
          >
            <option value="">Всі райони</option>
            {districts.map((d) => (
              <option key={d} value={d}>{d}</option>
            ))}
          </select>
        </div>

        <div>
          <label htmlFor="direction" className="block text-sm font-medium text-gray-700">Напрямок</label>
          <select
            id="direction"
            value={directionSlug}
            onChange={(e) => setDirectionSlug(e.target.value)}
            className="mt-1 rounded-md border border-gray-300 px-3 py-2 text-sm"
          >
            <option value="">Всі напрямки</option>
            {directions.map((d) => (
              <option key={d.id} value={d.slug}>{d.name}</option>
            ))}
          </select>
        </div>

        <div>
          <label htmlFor="age" className="block text-sm font-medium text-gray-700">Вік від</label>
          <input
            id="age"
            type="number"
            min={0}
            value={minAge}
            onChange={(e) => setMinAge(e.target.value)}
            className="mt-1 w-24 rounded-md border border-gray-300 px-3 py-2 text-sm"
          />
        </div>

        <div className="ml-auto flex overflow-hidden rounded-md border border-gray-300">
          <button
            onClick={() => setView('list')}
            className={`px-4 py-2 text-sm font-medium ${view === 'list' ? 'bg-adamas-black text-white' : 'bg-white text-gray-700'}`}
          >
            Список
          </button>
          <button
            onClick={() => setView('map')}
            className={`px-4 py-2 text-sm font-medium ${view === 'map' ? 'bg-adamas-black text-white' : 'bg-white text-gray-700'}`}
          >
            Карта
          </button>
        </div>
      </div>

      <p className="mt-4 text-sm text-gray-500">Знайдено: {filtered.length}</p>

      {view === 'list' ? (
        <div className="mt-6 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((loc) => (
            <div key={loc.id} className="card flex flex-col">
              <p className="font-display text-lg font-semibold">{loc.name}</p>
              <p className="mt-1 text-sm text-gray-600">{loc.address}</p>
              <p className="mt-2 text-xs uppercase tracking-wide text-gray-400">
                {loc.directions.map((d) => d.direction.name).join(' • ')}
              </p>
              <p className="mt-1 text-sm text-gray-600">Вік від {loc.minAge} років</p>
              <p className="mt-1 text-sm text-gray-600">Тренер: {loc.trainerName || loc.trainer?.name}</p>
              <div className="mt-4 flex flex-wrap gap-2">
                <Link href={`/locations/${loc.id}`} className="btn-secondary flex-1 text-center text-sm">
                  Детальніше
                </Link>
                <a href={`tel:${loc.phone.replace(/\s|\(|\)/g, '')}`} className="btn-secondary flex-1 text-center text-sm">
                  Зателефонувати
                </a>
              </div>
              <Link href={`/signup?locationId=${loc.id}`} className="btn-primary mt-2 text-center text-sm">
                Записатися
              </Link>
            </div>
          ))}
          {filtered.length === 0 && (
            <p className="col-span-full py-12 text-center text-gray-500">
              Нічого не знайдено. Спробуйте змінити фільтри.
            </p>
          )}
        </div>
      ) : (
        <div className="mt-6 h-[500px] w-full overflow-hidden rounded-xl border border-gray-200">
          <LocationsMap locations={filtered} />
        </div>
      )}
    </div>
  );
}
