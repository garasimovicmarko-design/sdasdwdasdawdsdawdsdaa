'use client';

import { useState } from 'react';

export default function ReviewForm() {
  const [name, setName] = useState('');
  const [text, setText] = useState('');
  const [rating, setRating] = useState(5);
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  const [error, setError] = useState<string | null>(null);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setStatus('submitting');
    setError(null);
    try {
      const res = await fetch('/api/reviews', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, text, rating })
      });
      const json = await res.json();
      if (!res.ok) {
        setError(json.error || 'Не вдалося відправити відгук.');
        setStatus('error');
        return;
      }
      setStatus('success');
      setName('');
      setText('');
      setRating(5);
    } catch {
      setError('Проблема з мережею.');
      setStatus('error');
    }
  }

  if (status === 'success') {
    return <p className="mt-4 rounded-md bg-green-50 px-4 py-3 text-sm text-green-700">Дякуємо! Ваш відгук на модерації.</p>;
  }

  return (
    <form onSubmit={onSubmit} className="mt-4 space-y-3">
      <input required placeholder="Ваше ім'я" value={name} onChange={(e) => setName(e.target.value)} className="w-full rounded-md border border-gray-300 px-3 py-2" />
      <textarea required placeholder="Ваш відгук" value={text} onChange={(e) => setText(e.target.value)} rows={4} className="w-full rounded-md border border-gray-300 px-3 py-2" />
      <select value={rating} onChange={(e) => setRating(Number(e.target.value))} className="rounded-md border border-gray-300 px-3 py-2">
        {[5, 4, 3, 2, 1].map((r) => <option key={r} value={r}>{r} {'★'.repeat(r)}</option>)}
      </select>
      {error && <p className="text-sm text-red-600">{error}</p>}
      <button type="submit" disabled={status === 'submitting'} className="btn-primary disabled:opacity-60">
        {status === 'submitting' ? 'Відправка...' : 'Відправити відгук'}
      </button>
    </form>
  );
}
