'use client';

import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

// Leaflet's default marker icons reference bundled assets that don't resolve
// correctly under Next.js's bundler — point them at the CDN copies instead.
const icon = L.icon({
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41]
});

type LocationItem = {
  id: string;
  name: string;
  address: string;
  latitude: number | null;
  longitude: number | null;
};

// Default center: Ivano-Frankivsk city center.
const DEFAULT_CENTER: [number, number] = [48.9226, 24.7111];

export default function LocationsMap({ locations }: { locations: LocationItem[] }) {
  const withCoords = locations.filter((l) => l.latitude !== null && l.longitude !== null);

  return (
    <MapContainer center={DEFAULT_CENTER} zoom={12} style={{ height: '100%', width: '100%' }}>
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      {withCoords.map((loc) => (
        <Marker key={loc.id} position={[loc.latitude as number, loc.longitude as number]} icon={icon}>
          <Popup>
            <strong>{loc.name}</strong>
            <br />
            {loc.address}
          </Popup>
        </Marker>
      ))}
      {withCoords.length === 0 && (
        <p style={{ position: 'absolute', zIndex: 1000, background: 'white', padding: 8 }}>
          Координати філій ще не додані. Додайте їх через адмін-панель.
        </p>
      )}
    </MapContainer>
  );
}
