'use client';

import { useState } from 'react';

type Direction = { id: string; name: string; slug: string };
type Trainer = { id: string; name: string };
type Location = {
  id: string;
  name: string;
  address: string;
  district: string | null;
  phone: string;
  trainerName: string | null;
  trainerId: string | null;
  minAge: number;
  active: boolean;
  hidden: boolean;
  latitude: number | null;
  longitude: number | null;
  directions: { direction: Direction }[];
};

const emptyForm = {
  name: '',
  address: '',
  district: '',
  phone: '',
  trainerId: '',
  minAge: 6,
  latitude: '',
  longitude: '',
  directionIds: [] as string[]
};

export default function AdminLocationsManager({
  initialLocations,
  directions,
  trainers
}: {
  initialLocations: Location[];
  directions: Direction[];
  trainers: Trainer[];
}) {
  const [locations, setLocations] = useState<Location[]>(initialLocations);
  const [form, setForm] = useState(emptyForm);
  const [creating, setCreating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    setCreating(true);
    setError(null);
    try {
      const res = await fetch('/api/admin/locations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...form,
          latitude: form.latitude ? Number(form.latitude) : undefined,
          longitude: form.longitude ? Number(form.longitude) : undefined
        })
      });
      const json = await res.json();
      if (!res.ok) {
        setError(json.error || 'Не вдалося створити філію.');
        return;
      }
      setLocations((prev) => [json.data, ...prev]);
      setForm(emptyForm);
    } catch {
      setError('Проблема з мережею.');
    } finally {
      setCreating(false);
    }
  }

  async function toggleHidden(loc: Location) {
    const res = await fetch(`/api/admin/locations/${loc.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ hidden: !loc.hidden })
    });
    if (res.ok) {
      setLocations((prev) => prev.map((l) => (l.id === loc.id ? { ...l, hidden: !l.hidden } : l)));
    }
  }

  async function remove(id: string) {
    if (!confirm('Видалити цю філію безповоротно?')) return;
    const res = await fetch(`/api/admin/locations/${id}`, { method: 'DELETE' });
    if (res.ok) setLocations((prev) => prev.filter((l) => l.id !== id));
  }

  return (
    <div className="mt-6 space-y-10">
      <form onSubmit={handleCreate} className="grid grid-cols-1 gap-3 rounded-lg border border-gray-200 p-4 sm:grid-cols-2 lg:grid-cols-3">
        <input required placeholder="Назва" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="rounded-md border border-gray-300 px-3 py-2" />
        <input required placeholder="Адреса" value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} className="rounded-md border border-gray-300 px-3 py-2" />
        <input placeholder="Район" value={form.district} onChange={(e) => setForm({ ...form, district: e.target.value })} className="rounded-md border border-gray-300 px-3 py-2" />
        <input required placeholder="Телефон" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="rounded-md border border-gray-300 px-3 py-2" />
        <select value={form.trainerId} onChange={(e) => setForm({ ...form, trainerId: e.target.value })} className="rounded-md border border-gray-300 px-3 py-2">
          <option value="">Тренер</option>
          {trainers.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}
        </select>
        <input type="number" placeholder="Вік від" value={form.minAge} onChange={(e) => setForm({ ...form, minAge: Number(e.target.value) })} className="rounded-md border border-gray-300 px-3 py-2" />
        <input placeholder="Широта (lat)" value={form.latitude} onChange={(e) => setForm({ ...form, latitude: e.target.value })} className="rounded-md border border-gray-300 px-3 py-2" />
        <input placeholder="Довгота (lng)" value={form.longitude} onChange={(e) => setForm({ ...form, longitude: e.target.value })} className="rounded-md border border-gray-300 px-3 py-2" />
        <div className="flex flex-wrap gap-3 sm:col-span-2 lg:col-span-1">
          {directions.map((d) => (
            <label key={d.id} className="flex items-center gap-1 text-sm">
              <input
                type="checkbox"
                checked={form.directionIds.includes(d.id)}
                onChange={(e) =>
                  setForm({
                    ...form,
                    directionIds: e.target.checked
                      ? [...form.directionIds, d.id]
                      : form.directionIds.filter((id) => id !== d.id)
                  })
                }
              />
              {d.name}
            </label>
          ))}
        </div>
        <button type="submit" disabled={creating} className="btn-primary sm:col-span-2 lg:col-span-3">
          {creating ? 'Створення...' : 'Додати філію'}
        </button>
        {error && <p className="text-sm text-red-600 sm:col-span-2 lg:col-span-3">{error}</p>}
      </form>

      <div className="overflow-hidden rounded-lg border border-gray-200">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 text-left">
            <tr>
              <th className="px-4 py-2">Назва</th>
              <th className="px-4 py-2">Адреса</th>
              <th className="px-4 py-2">Тренер</th>
              <th className="px-4 py-2">Статус</th>
              <th className="px-4 py-2">Дії</th>
            </tr>
          </thead>
          <tbody>
            {locations.map((loc) => (
              <tr key={loc.id} className="border-t border-gray-100">
                <td className="px-4 py-2">{loc.name}</td>
                <td className="px-4 py-2">{loc.address}</td>
                <td className="px-4 py-2">{loc.trainerName}</td>
                <td className="px-4 py-2">{loc.hidden ? 'Приховано' : 'Активна'}</td>
                <td className="px-4 py-2 space-x-2">
                  <button onClick={() => toggleHidden(loc)} className="text-adamas-red underline">
                    {loc.hidden ? 'Показати' : 'Приховати'}
                  </button>
                  <button onClick={() => remove(loc.id)} className="text-gray-500 underline">Видалити</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
