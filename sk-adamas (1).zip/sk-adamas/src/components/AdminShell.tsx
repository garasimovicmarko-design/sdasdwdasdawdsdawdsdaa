'use client';

import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';

const links = [
  { href: '/admin', label: 'Dashboard' },
  { href: '/admin/locations', label: 'Філії' },
  { href: '/admin/signups', label: 'Заявки' }
];

export default function AdminShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();

  async function logout() {
    await fetch('/api/admin/logout', { method: 'POST' });
    router.push('/admin/login');
    router.refresh();
  }

  return (
    <div className="flex min-h-[80vh]">
      <aside className="w-56 shrink-0 border-r border-gray-200 bg-gray-50 p-4">
        <p className="font-display text-sm font-bold uppercase tracking-wide text-gray-500">SK ADAMAS Admin</p>
        <nav className="mt-6 flex flex-col gap-1">
          {links.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              className={`rounded-md px-3 py-2 text-sm font-medium ${
                pathname === l.href ? 'bg-adamas-black text-white' : 'text-gray-700 hover:bg-gray-100'
              }`}
            >
              {l.label}
            </Link>
          ))}
        </nav>
        <button onClick={logout} className="mt-8 w-full rounded-md border border-gray-300 px-3 py-2 text-sm">
          Вийти
        </button>
      </aside>
      <div className="flex-1 p-8">{children}</div>
    </div>
  );
}
