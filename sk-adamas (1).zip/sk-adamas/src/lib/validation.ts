import { z } from 'zod';

// Ukrainian-friendly phone check: allows +380XXXXXXXXX or local formats with spaces/dashes.
const phoneRegex = /^\+?[0-9\s()-]{9,20}$/;

export const signupSchema = z
  .object({
    childName: z.string().trim().min(2, "Введіть ім'я та прізвище").max(120),
    age: z.coerce.number().int().min(3, 'Вкажіть вік').max(99),
    contactName: z.string().trim().min(2, "Введіть ім'я контактної особи").max(120),
    contactPhone: z.string().trim().regex(phoneRegex, 'Введіть коректний номер телефону'),
    directionId: z.string().cuid().optional().or(z.literal('')),
    locationId: z.string().cuid().optional().or(z.literal('')),
    trainingGroupId: z.string().cuid().optional().or(z.literal('')),
    comment: z.string().trim().max(1000).optional().or(z.literal('')),
    consentPolicy: z.literal(true, {
      errorMap: () => ({ message: 'Потрібна згода з політикою конфіденційності' })
    })
  })
  .transform((data) => ({
    ...data,
    isMinor: data.age < 18,
    directionId: data.directionId || undefined,
    locationId: data.locationId || undefined,
    trainingGroupId: data.trainingGroupId || undefined,
    comment: data.comment || undefined
  }));

export type SignupInput = z.infer<typeof signupSchema>;

export const reviewSchema = z.object({
  name: z.string().trim().min(2).max(120),
  text: z.string().trim().min(5).max(2000),
  rating: z.coerce.number().int().min(1).max(5)
});

export const loginSchema = z.object({
  email: z.string().trim().email(),
  password: z.string().min(8).max(200)
});

export const locationSchema = z.object({
  name: z.string().trim().min(2).max(200),
  address: z.string().trim().min(3).max(300),
  district: z.string().trim().max(100).optional().or(z.literal('')),
  phone: z.string().trim().regex(phoneRegex),
  trainerId: z.string().cuid().optional().or(z.literal('')),
  trainerName: z.string().trim().max(200).optional().or(z.literal('')),
  latitude: z.coerce.number().min(-90).max(90).optional(),
  longitude: z.coerce.number().min(-180).max(180).optional(),
  photoUrl: z.string().url().optional().or(z.literal('')),
  minAge: z.coerce.number().int().min(0).max(99).default(6),
  active: z.coerce.boolean().default(true),
  hidden: z.coerce.boolean().default(false),
  directionIds: z.array(z.string().cuid()).optional().default([])
});
