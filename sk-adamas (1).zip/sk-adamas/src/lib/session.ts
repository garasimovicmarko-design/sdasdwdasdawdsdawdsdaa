import { getIronSession, IronSession, SessionOptions } from 'iron-session';
import { cookies } from 'next/headers';

export interface AdminSessionData {
  adminId?: string;
  email?: string;
  loggedInAt?: number;
}

if (!process.env.AUTH_SECRET || process.env.AUTH_SECRET.length < 32) {
  // Fail fast in any real environment — never run with a weak/missing secret.
  if (process.env.NODE_ENV === 'production') {
    throw new Error('AUTH_SECRET must be set and at least 32 characters long in production.');
  }
}

export const sessionOptions: SessionOptions = {
  password: process.env.AUTH_SECRET || 'dev-only-insecure-secret-change-me-please-32chars',
  cookieName: 'adamas_admin_session',
  cookieOptions: {
    secure: process.env.NODE_ENV === 'production',
    httpOnly: true,
    sameSite: 'lax',
    maxAge: 60 * 60 * 8 // 8 hours
  }
};

export async function getAdminSession(): Promise<IronSession<AdminSessionData>> {
  return getIronSession<AdminSessionData>(cookies(), sessionOptions);
}

export async function requireAdminSession() {
  const session = await getAdminSession();
  if (!session.adminId) {
    throw new Error('UNAUTHORIZED');
  }
  return session;
}
