import type { Metadata } from 'next';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { prisma } from '@/lib/prisma';

const weekdayLabels: Record<string, string> = {
  MON: 'Понеділок', TUE: 'Вівторок', WED: 'Середа', THU: 'Четвер', FRI: "П'ятниця", SAT: 'Субота', SUN: 'Неділя'
};

export async function generateMetadata({ params }: { params: { id: string } }): Promise<Metadata> {
  const location = await prisma.location.findUnique({ where: { id: params.id } });
  if (!location) return { title: 'Філію не знайдено' };
  return {
    title: location.name,
    description: `${location.name}, ${location.address} — тхеквондо та кікбоксинг ISKA для дітей та дорослих.`
  };
}

export default async function LocationDetailPage({ params }: { params: { id: string } }) {
  const location = await prisma.location.findUnique({
    where: { id: params.id },
    include: {
      directions: { include: { direction: true } },
      trainer: true,
      schedules: { where: { active: true }, orderBy: [{ weekday: 'asc' }, { startTime: 'asc' }] },
      trainingGroups: { where: { active: true } }
    }
  });

  if (!location || location.hidden) notFound();

  const telHref = `tel:${location.phone.replace(/\s|\(|\)/g, '')}`;

  return (
    <div className="container-adamas py-12">
      <Link href="/locations" className="text-sm text-adamas-red">← Всі філії</Link>
      <h1 className="mt-2 font-display text-3xl font-bold">{location.name}</h1>
      <p className="mt-1 text-gray-600">{location.address}</p>

      <div className="mt-8 grid grid-cols-1 gap-10 lg:grid-cols-3">
        <div className="lg:col-span-2 space-y-8">
          <section>
            <h2 className="font-display text-xl font-semibold">Напрямки та вік</h2>
            <p className="mt-2 text-sm text-gray-600">
              {location.directions.map((d) => d.direction.name).join(', ')} — від {location.minAge} років
            </p>
          </section>

          <section>
            <h2 className="font-display text-xl font-semibold">Тренер</h2>
            <p className="mt-2 text-sm text-gray-600">{location.trainerName || location.trainer?.name}</p>
          </section>

          <section>
            <h2 className="font-display text-xl font-semibold">Розклад</h2>
            {location.schedules.length === 0 ? (
              <p className="mt-2 text-sm text-gray-500">Розклад цієї філії ще уточнюється — зателефонуйте нам.</p>
            ) : (
              <div className="mt-3 overflow-hidden rounded-lg border border-gray-200">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50 text-left">
                    <tr>
                      <th className="px-4 py-2">День</th>
                      <th className="px-4 py-2">Час</th>
                      <th className="px-4 py-2">Напрямок</th>
                    </tr>
                  </thead>
                  <tbody>
                    {location.schedules.map((s) => (
                      <tr key={s.id} className="border-t border-gray-100">
                        <td className="px-4 py-2">{weekdayLabels[s.weekday]}</td>
                        <td className="px-4 py-2">{s.startTime}–{s.endTime}</td>
                        <td className="px-4 py-2">{s.trainingGroupId ? '' : ''}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </section>
        </div>

        <aside className="card h-fit">
          <p className="font-semibold">Контакти</p>
          <a href={telHref} className="mt-2 block text-lg font-semibold text-adamas-red">{location.phone}</a>
          <Link href={`/signup?locationId=${location.id}`} className="btn-primary mt-4 w-full text-center">
            Записатися на тренування
          </Link>
        </aside>
      </div>
    </div>
  );
}
