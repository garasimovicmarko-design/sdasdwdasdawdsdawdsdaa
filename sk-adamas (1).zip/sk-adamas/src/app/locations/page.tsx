import type { Metadata } from 'next';
import { prisma } from '@/lib/prisma';
import LocationsExplorer from '@/components/LocationsExplorer';

export const metadata: Metadata = {
  title: 'Філії клубу',
  description: 'Всі філії SK ADAMAS у Івано-Франківську та області — адреси, тренери, розклад.'
};

export const revalidate = 300;

export default async function LocationsPage() {
  const [locations, directions] = await Promise.all([
    prisma.location.findMany({
      where: { active: true, hidden: false },
      include: { directions: { include: { direction: true } }, trainer: true },
      orderBy: { name: 'asc' }
    }),
    prisma.direction.findMany({ where: { active: true } })
  ]);

  const districts = Array.from(new Set(locations.map((l) => l.district).filter(Boolean))) as string[];

  return (
    <div className="container-adamas py-12">
      <h1 className="font-display text-3xl font-bold">Філії SK ADAMAS</h1>
      <p className="mt-2 text-gray-600">Оберіть зал, зручний за розташуванням, тренером або розкладом.</p>

      <LocationsExplorer
        locations={JSON.parse(JSON.stringify(locations))}
        directions={JSON.parse(JSON.stringify(directions))}
        districts={districts}
      />
    </div>
  );
}
