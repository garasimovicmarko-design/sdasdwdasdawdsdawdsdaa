import type { Metadata } from 'next';

export const metadata: Metadata = { title: 'Умови використання' };

export default function TermsPage() {
  return (
    <div className="container-adamas py-12">
      <h1 className="font-display text-3xl font-bold">Умови використання</h1>
      <div className="prose mt-6 max-w-2xl text-gray-700">
        <p>
          Використовуючи цей сайт, ви погоджуєтесь надавати достовірну інформацію у формах запису та
          відгуків. Адміністрація клубу залишає за собою право відхилити заявку або відгук, що
          порушує загальні норми моралі або містить недостовірні дані.
        </p>
        <p>Замініть цей текст на остаточну редакцію умов використання через адмін-панель.</p>
      </div>
    </div>
  );
}
