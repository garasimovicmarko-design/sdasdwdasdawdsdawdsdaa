import { redirect } from 'next/navigation';
import { getAdminSession } from '@/lib/session';
import { prisma } from '@/lib/prisma';
import AdminShell from '@/components/AdminShell';

export default async function AdminDashboardPage() {
  const session = await getAdminSession();
  if (!session.adminId) redirect('/admin/login');

  const [totalSignups, newSignups, totalLocations, totalSchedule, totalTrainers, recentSignups] = await Promise.all([
    prisma.signup.count(),
    prisma.signup.count({ where: { status: 'NEW' } }),
    prisma.location.count({ where: { active: true } }),
    prisma.schedule.count({ where: { active: true } }),
    prisma.trainer.count({ where: { active: true } }),
    prisma.signup.findMany({
      orderBy: { createdAt: 'desc' },
      take: 10,
      include: { direction: true, location: true }
    })
  ]);

  const stats = [
    { label: 'Всього заявок', value: totalSignups },
    { label: 'Нові заявки', value: newSignups },
    { label: 'Філії', value: totalLocations },
    { label: 'Тренування в розкладі', value: totalSchedule },
    { label: 'Тренери', value: totalTrainers }
  ];

  return (
    <AdminShell>
      <h1 className="font-display text-2xl font-bold">Dashboard</h1>

      <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-5">
        {stats.map((s) => (
          <div key={s.label} className="rounded-lg border border-gray-200 p-4">
            <p className="text-2xl font-bold">{s.value}</p>
            <p className="mt-1 text-xs text-gray-500">{s.label}</p>
          </div>
        ))}
      </div>

      <h2 className="mt-10 font-display text-lg font-semibold">Останні заявки</h2>
      <div className="mt-4 overflow-hidden rounded-lg border border-gray-200">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 text-left">
            <tr>
              <th className="px-4 py-2">Учасник</th>
              <th className="px-4 py-2">Контакт</th>
              <th className="px-4 py-2">Напрямок</th>
              <th className="px-4 py-2">Філія</th>
              <th className="px-4 py-2">Статус</th>
            </tr>
          </thead>
          <tbody>
            {recentSignups.map((s) => (
              <tr key={s.id} className="border-t border-gray-100">
                <td className="px-4 py-2">{s.childName} ({s.age})</td>
                <td className="px-4 py-2">{s.contactName}, {s.contactPhone}</td>
                <td className="px-4 py-2">{s.direction?.name || '—'}</td>
                <td className="px-4 py-2">{s.location?.name || '—'}</td>
                <td className="px-4 py-2">{s.status}</td>
              </tr>
            ))}
            {recentSignups.length === 0 && (
              <tr><td colSpan={5} className="px-4 py-6 text-center text-gray-400">Заявок ще немає</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </AdminShell>
  );
}
