import { redirect } from 'next/navigation';
import { getAdminSession } from '@/lib/session';
import { prisma } from '@/lib/prisma';
import AdminShell from '@/components/AdminShell';
import AdminSignupsManager from '@/components/AdminSignupsManager';

export default async function AdminSignupsPage() {
  const session = await getAdminSession();
  if (!session.adminId) redirect('/admin/login');

  const signups = await prisma.signup.findMany({
    include: { direction: true, location: true },
    orderBy: { createdAt: 'desc' }
  });

  return (
    <AdminShell>
      <h1 className="font-display text-2xl font-bold">Заявки</h1>
      <AdminSignupsManager initialSignups={JSON.parse(JSON.stringify(signups))} />
    </AdminShell>
  );
}
