import { redirect } from 'next/navigation';
import { getAdminSession } from '@/lib/session';
import { prisma } from '@/lib/prisma';
import AdminShell from '@/components/AdminShell';
import AdminLocationsManager from '@/components/AdminLocationsManager';

export default async function AdminLocationsPage() {
  const session = await getAdminSession();
  if (!session.adminId) redirect('/admin/login');

  const [locations, directions, trainers] = await Promise.all([
    prisma.location.findMany({
      include: { directions: { include: { direction: true } }, trainer: true },
      orderBy: { createdAt: 'desc' }
    }),
    prisma.direction.findMany({ where: { active: true } }),
    prisma.trainer.findMany({ where: { active: true } })
  ]);

  return (
    <AdminShell>
      <h1 className="font-display text-2xl font-bold">Філії</h1>
      <AdminLocationsManager
        initialLocations={JSON.parse(JSON.stringify(locations))}
        directions={JSON.parse(JSON.stringify(directions))}
        trainers={JSON.parse(JSON.stringify(trainers))}
      />
    </AdminShell>
  );
}
