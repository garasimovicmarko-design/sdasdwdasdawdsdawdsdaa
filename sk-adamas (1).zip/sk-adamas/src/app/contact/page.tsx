import type { Metadata } from 'next';
import Link from 'next/link';

export const metadata: Metadata = { title: 'Контакти' };

export default function ContactPage() {
  return (
    <div className="container-adamas py-12">
      <h1 className="font-display text-3xl font-bold">Контакти</h1>
      <p className="mt-4 max-w-xl text-gray-600">
        Оберіть найближчу філію на сторінці{' '}
        <Link href="/locations" className="text-adamas-red underline">філій</Link>, щоб побачити телефон
        тренера цього залу, або залиште заявку — ми зателефонуємо вам самі.
      </p>
      <div className="mt-6 flex flex-wrap gap-3">
        <Link href="/signup" className="btn-primary">Записатися на тренування</Link>
        <a href="https://www.instagram.com/adamas_ua" target="_blank" rel="noopener noreferrer" className="btn-secondary">
          Instagram
        </a>
      </div>
    </div>
  );
}
