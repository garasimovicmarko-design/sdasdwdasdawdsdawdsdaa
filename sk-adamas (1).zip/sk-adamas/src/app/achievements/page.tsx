import type { Metadata } from 'next';
import Image from 'next/image';

export const metadata: Metadata = { title: 'Досягнення' };

const photos = [
  { src: '/images/team-flag.png', caption: 'Команда SK ADAMAS з прапором України та сертифікатом ISKA Amateur Members World Championships 2023' },
  { src: '/images/champions-belts.png', caption: 'Чемпіонські пояси ISKA' },
  { src: '/images/iska-ukraine-championship.png', caption: 'Чемпіонат України ISKA' },
  { src: '/images/team-medals-italy.png', caption: 'Спортсмени клубу на змаганнях з нагородами' }
];

export default function AchievementsPage() {
  return (
    <div className="container-adamas py-12">
      <h1 className="font-display text-3xl font-bold">Досягнення</h1>
      <p className="mt-4 max-w-2xl text-gray-600">
        Наші спортсмени беруть активну участь в обласних, національних та міжнародних змаганнях,
        відвідують навчально-тренувальні збори та проходять атестації на пояси. Серед вихованців
        клубу є чемпіони та призери чемпіонатів Європи та Світу, а також члени збірної команди
        України.
      </p>

      <div className="mt-8 grid grid-cols-1 gap-6 sm:grid-cols-2">
        {photos.map((p) => (
          <figure key={p.src} className="overflow-hidden rounded-xl">
            <div className="relative aspect-[4/3]">
              <Image src={p.src} alt={p.caption} fill className="object-cover" />
            </div>
            <figcaption className="mt-2 text-sm text-gray-600">{p.caption}</figcaption>
          </figure>
        ))}
      </div>

      <p className="mt-8 text-sm text-gray-400">
        Конкретні імена спортсменів, кількість медалей та місця змагань додаються адміністрацією
        клубу через розділ «Досягнення» в адмін-панелі, щоб інформація завжди була точною та
        актуальною.
      </p>
    </div>
  );
}
