import type { Metadata } from 'next';
import Image from 'next/image';
import { prisma } from '@/lib/prisma';

export const metadata: Metadata = { title: 'Галерея' };
export const revalidate = 300;

export default async function GalleryPage() {
  const items = await prisma.galleryItem.findMany({ orderBy: { sortOrder: 'asc' } });

  return (
    <div className="container-adamas py-12">
      <h1 className="font-display text-3xl font-bold">Галерея</h1>
      {items.length === 0 ? (
        <p className="mt-8 text-gray-500">
          Фотографії клубу з'являться тут найближчим часом — вони додаються через адмін-панель.
        </p>
      ) : (
        <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {items.map((item) => (
            <figure key={item.id} className="overflow-hidden rounded-lg">
              <div className="relative aspect-square">
                <Image src={item.imageUrl} alt={item.caption || 'SK ADAMAS'} fill className="object-cover" />
              </div>
              {item.caption && <figcaption className="mt-1 text-xs text-gray-500">{item.caption}</figcaption>}
            </figure>
          ))}
        </div>
      )}
    </div>
  );
}
