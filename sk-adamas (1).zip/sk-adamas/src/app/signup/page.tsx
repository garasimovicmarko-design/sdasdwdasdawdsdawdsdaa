import type { Metadata } from 'next';
import { prisma } from '@/lib/prisma';
import SignupForm from '@/components/SignupForm';

export const metadata: Metadata = {
  title: 'Запис на тренування',
  description: 'Заповніть форму, щоб записатися на тренування з тхеквондо або кікбоксингу ISKA.'
};

export const revalidate = 300;

export default async function SignupPage({
  searchParams
}: {
  searchParams: { locationId?: string; directionId?: string };
}) {
  const [locations, directions] = await Promise.all([
    prisma.location.findMany({ where: { active: true, hidden: false }, orderBy: { name: 'asc' } }),
    prisma.direction.findMany({ where: { active: true } })
  ]);

  return (
    <div className="container-adamas py-12">
      <div className="mx-auto max-w-2xl">
        <h1 className="font-display text-3xl font-bold">Запис на тренування</h1>
        <p className="mt-2 text-gray-600">
          Заповніть форму нижче — ми зателефонуємо вам, щоб узгодити деталі першого тренування.
        </p>

        <SignupForm
          locations={JSON.parse(JSON.stringify(locations))}
          directions={JSON.parse(JSON.stringify(directions))}
          defaultLocationId={searchParams.locationId}
          defaultDirectionId={searchParams.directionId}
        />
      </div>
    </div>
  );
}
