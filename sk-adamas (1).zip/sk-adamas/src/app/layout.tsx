import type { Metadata } from 'next';
import './globals.css';
import Header from '@/components/Header';
import Footer from '@/components/Footer';

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://adamas.example.com';

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: 'SK ADAMAS — Тхеквондо та Кікбоксинг ISKA в Івано-Франківську',
    template: '%s | SK ADAMAS'
  },
  description:
    'Спортивний клуб SK ADAMAS проводить набір у групи з тхеквондо та кікбоксингу ISKA для дітей та дорослих від 6 років. 19 філій у Івано-Франківську та області.',
  openGraph: {
    title: 'SK ADAMAS — Спортивний клуб',
    description: 'Тхеквондо та Кікбоксинг ISKA для дітей та дорослих в Івано-Франківську.',
    url: siteUrl,
    siteName: 'SK ADAMAS',
    locale: 'uk_UA',
    type: 'website'
  },
  twitter: {
    card: 'summary_large_image',
    title: 'SK ADAMAS — Спортивний клуб',
    description: 'Тхеквондо та Кікбоксинг ISKA для дітей та дорослих в Івано-Франківську.'
  },
  alternates: { canonical: siteUrl }
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  const jsonLd = {
    '@context': 'https://schema.org',
    '@type': 'SportsActivityLocation',
    name: 'SK ADAMAS',
    description: 'Спортивний клуб з тхеквондо та кікбоксингу ISKA у Івано-Франківську.',
    areaServed: 'Івано-Франківськ',
    sameAs: ['https://www.instagram.com/adamas_ua']
  };

  return (
    <html lang="uk">
      <body className="flex min-h-screen flex-col font-body">
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
        <Header />
        <main className="flex-1">{children}</main>
        <Footer />
      </body>
    </html>
  );
}
