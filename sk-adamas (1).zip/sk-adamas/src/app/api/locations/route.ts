import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const district = searchParams.get('district') || undefined;
  const directionSlug = searchParams.get('direction') || undefined;
  const age = searchParams.get('age');
  const q = searchParams.get('q') || undefined;

  try {
    const locations = await prisma.location.findMany({
      where: {
        active: true,
        hidden: false,
        ...(district ? { district } : {}),
        ...(age ? { minAge: { lte: Number(age) } } : {}),
        ...(q
          ? {
              OR: [
                { name: { contains: q, mode: 'insensitive' } },
                { address: { contains: q, mode: 'insensitive' } }
              ]
            }
          : {}),
        ...(directionSlug
          ? { directions: { some: { direction: { slug: directionSlug } } } }
          : {})
      },
      include: {
        directions: { include: { direction: true } },
        trainer: true
      },
      orderBy: { name: 'asc' }
    });

    return NextResponse.json({ data: locations });
  } catch (err) {
    console.error('GET /api/locations failed', err);
    return NextResponse.json(
      { error: 'Не вдалося завантажити список філій. Спробуйте пізніше.' },
      { status: 500 }
    );
  }
}
