import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const location = await prisma.location.findUnique({
      where: { id: params.id },
      include: {
        directions: { include: { direction: true } },
        trainer: true,
        schedules: { where: { active: true }, orderBy: [{ weekday: 'asc' }, { startTime: 'asc' }] },
        trainingGroups: { where: { active: true } }
      }
    });

    if (!location || location.hidden) {
      return NextResponse.json({ error: 'Філію не знайдено.' }, { status: 404 });
    }

    return NextResponse.json({ data: location });
  } catch (err) {
    console.error('GET /api/locations/[id] failed', err);
    return NextResponse.json({ error: 'Сталася помилка. Спробуйте пізніше.' }, { status: 500 });
  }
}
