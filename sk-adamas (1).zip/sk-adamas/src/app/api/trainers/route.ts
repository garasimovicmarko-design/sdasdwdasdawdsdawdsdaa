import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET() {
  try {
    const trainers = await prisma.trainer.findMany({
      where: { active: true },
      include: { locations: { select: { id: true, name: true } } },
      orderBy: { name: 'asc' }
    });
    return NextResponse.json({ data: trainers });
  } catch (err) {
    console.error('GET /api/trainers failed', err);
    return NextResponse.json({ error: 'Не вдалося завантажити тренерів.' }, { status: 500 });
  }
}
