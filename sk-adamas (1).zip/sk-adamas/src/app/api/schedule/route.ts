import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { Weekday } from '@prisma/client';

const validWeekdays = new Set(Object.values(Weekday));

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const locationId = searchParams.get('locationId') || undefined;
  const directionSlug = searchParams.get('direction') || undefined;
  const weekdayParam = searchParams.get('weekday') || undefined;
  const weekday =
    weekdayParam && validWeekdays.has(weekdayParam as Weekday) ? (weekdayParam as Weekday) : undefined;

  try {
    const schedule = await prisma.schedule.findMany({
      where: {
        active: true,
        ...(locationId ? { locationId } : {}),
        ...(weekday ? { weekday } : {}),
        ...(directionSlug ? { direction: { slug: directionSlug } } : {})
      },
      include: {
        location: { select: { id: true, name: true, address: true } },
        direction: true,
        trainer: true,
        trainingGroup: true
      },
      orderBy: [{ weekday: 'asc' }, { startTime: 'asc' }]
    });

    return NextResponse.json({ data: schedule });
  } catch (err) {
    console.error('GET /api/schedule failed', err);
    return NextResponse.json({ error: 'Не вдалося завантажити розклад.' }, { status: 500 });
  }
}
