import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { reviewSchema } from '@/lib/validation';
import { rateLimit } from '@/lib/rateLimit';

export async function GET() {
  try {
    const reviews = await prisma.review.findMany({
      where: { status: 'APPROVED' },
      orderBy: { createdAt: 'desc' }
    });
    return NextResponse.json({ data: reviews });
  } catch (err) {
    console.error('GET /api/reviews failed', err);
    return NextResponse.json({ error: 'Не вдалося завантажити відгуки.' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  const ip = req.headers.get('x-forwarded-for') || 'unknown';
  const rl = rateLimit(`review:${ip}`, 5, 60 * 60 * 1000);
  if (!rl.allowed) {
    return NextResponse.json({ error: 'Забагато відгуків з вашої IP-адреси. Спробуйте пізніше.' }, { status: 429 });
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Некоректний формат запиту.' }, { status: 400 });
  }

  const parsed = reviewSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message || 'Перевірте форму.' }, { status: 400 });
  }

  try {
    const review = await prisma.review.create({
      data: { ...parsed.data, status: 'PENDING' }
    });
    return NextResponse.json(
      { data: { id: review.id }, message: 'Дякуємо! Ваш відгук буде опубліковано після модерації.' },
      { status: 201 }
    );
  } catch (err) {
    console.error('POST /api/reviews failed', err);
    return NextResponse.json({ error: 'Не вдалося зберегти відгук.' }, { status: 500 });
  }
}
