import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET() {
  try {
    const news = await prisma.news.findMany({
      where: { published: true },
      orderBy: { publishedAt: 'desc' },
      select: { id: true, title: true, slug: true, excerpt: true, coverImage: true, publishedAt: true }
    });
    return NextResponse.json({ data: news });
  } catch (err) {
    console.error('GET /api/news failed', err);
    return NextResponse.json({ error: 'Не вдалося завантажити новини.' }, { status: 500 });
  }
}
