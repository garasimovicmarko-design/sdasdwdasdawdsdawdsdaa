import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET(_req: NextRequest, { params }: { params: { slug: string } }) {
  try {
    const article = await prisma.news.findUnique({ where: { slug: params.slug } });
    if (!article || !article.published) {
      return NextResponse.json({ error: 'Новину не знайдено.' }, { status: 404 });
    }
    return NextResponse.json({ data: article });
  } catch (err) {
    console.error('GET /api/news/[slug] failed', err);
    return NextResponse.json({ error: 'Сталася помилка.' }, { status: 500 });
  }
}
