import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { signupSchema } from '@/lib/validation';
import { rateLimit } from '@/lib/rateLimit';

export async function POST(req: NextRequest) {
  const ip = req.headers.get('x-forwarded-for') || 'unknown';
  const rl = rateLimit(`signup:${ip}`, 5, 10 * 60 * 1000); // 5 submissions / 10 min / IP
  if (!rl.allowed) {
    return NextResponse.json(
      { error: 'Забагато спроб. Спробуйте, будь ласка, трохи пізніше.' },
      { status: 429 }
    );
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Некоректний формат запиту.' }, { status: 400 });
  }

  const parsed = signupSchema.safeParse(body);
  if (!parsed.success) {
    const firstIssue = parsed.error.issues[0];
    return NextResponse.json(
      { error: firstIssue?.message || 'Перевірте правильність заповнення форми.', fieldErrors: parsed.error.flatten().fieldErrors },
      { status: 400 }
    );
  }

  const data = parsed.data;

  try {
    const signup = await prisma.signup.create({
      data: {
        childName: data.childName,
        age: data.age,
        contactName: data.contactName,
        contactPhone: data.contactPhone,
        isMinor: data.isMinor,
        directionId: data.directionId,
        locationId: data.locationId,
        trainingGroupId: data.trainingGroupId,
        comment: data.comment,
        consentPolicy: data.consentPolicy,
        status: 'NEW'
      }
    });

    return NextResponse.json(
      { data: { id: signup.id }, message: 'Заявку прийнято! Ми зв\u2019яжемося з вами найближчим часом.' },
      { status: 201 }
    );
  } catch (err) {
    console.error('POST /api/signup failed', err);
    return NextResponse.json(
      { error: 'Не вдалося відправити заявку. Спробуйте ще раз або зателефонуйте нам напряму.' },
      { status: 500 }
    );
  }
}
