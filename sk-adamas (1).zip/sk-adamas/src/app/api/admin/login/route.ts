import { NextRequest, NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { prisma } from '@/lib/prisma';
import { loginSchema } from '@/lib/validation';
import { getAdminSession } from '@/lib/session';
import { rateLimit } from '@/lib/rateLimit';

export async function POST(req: NextRequest) {
  const ip = req.headers.get('x-forwarded-for') || 'unknown';
  const rl = rateLimit(`admin-login:${ip}`, 8, 15 * 60 * 1000); // 8 attempts / 15 min / IP
  if (!rl.allowed) {
    return NextResponse.json(
      { error: 'Забагато спроб входу. Спробуйте пізніше.' },
      { status: 429 }
    );
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Некоректний запит.' }, { status: 400 });
  }

  const parsed = loginSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: 'Введіть коректні email та пароль.' }, { status: 400 });
  }

  const { email, password } = parsed.data;

  // Always run bcrypt.compare even on a missing user, to avoid a timing
  // side-channel that reveals whether an email exists.
  const admin = await prisma.admin.findUnique({ where: { email } });
  const hashToCompare = admin?.passwordHash ?? '$2a$12$invalidsaltinvalidsaltinvalidsaltinvalidsalt.......';
  const passwordMatches = await bcrypt.compare(password, hashToCompare);

  if (!admin || !admin.active || !passwordMatches) {
    return NextResponse.json({ error: 'Невірний email або пароль.' }, { status: 401 });
  }

  const session = await getAdminSession();
  session.adminId = admin.id;
  session.email = admin.email;
  session.loggedInAt = Date.now();
  await session.save();

  return NextResponse.json({ data: { email: admin.email, name: admin.name } });
}
