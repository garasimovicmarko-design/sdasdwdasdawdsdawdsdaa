import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getAdminSession } from '@/lib/session';
import { locationSchema } from '@/lib/validation';

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getAdminSession();
  if (!session.adminId) return NextResponse.json({ error: 'Не авторизовано.' }, { status: 401 });

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Некоректний запит.' }, { status: 400 });
  }

  const parsed = locationSchema.partial().safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message || 'Перевірте форму.' }, { status: 400 });
  }

  const { directionIds, district, trainerId, trainerName, photoUrl, ...rest } = parsed.data;

  try {
    const location = await prisma.location.update({
      where: { id: params.id },
      data: {
        ...rest,
        ...(district !== undefined ? { district: district || null } : {}),
        ...(trainerId !== undefined ? { trainerId: trainerId || null } : {}),
        ...(trainerName !== undefined ? { trainerName: trainerName || null } : {}),
        ...(photoUrl !== undefined ? { photoUrl: photoUrl || null } : {}),
        ...(directionIds
          ? {
              directions: {
                deleteMany: {},
                create: directionIds.map((directionId) => ({ directionId }))
              }
            }
          : {})
      }
    });
    return NextResponse.json({ data: location });
  } catch (err) {
    console.error('PATCH /api/admin/locations/[id] failed', err);
    return NextResponse.json({ error: 'Не вдалося оновити філію.' }, { status: 500 });
  }
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getAdminSession();
  if (!session.adminId) return NextResponse.json({ error: 'Не авторизовано.' }, { status: 401 });

  try {
    await prisma.location.delete({ where: { id: params.id } });
    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error('DELETE /api/admin/locations/[id] failed', err);
    return NextResponse.json({ error: 'Не вдалося видалити філію.' }, { status: 500 });
  }
}
