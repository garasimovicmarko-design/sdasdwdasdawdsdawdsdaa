import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getAdminSession } from '@/lib/session';
import { locationSchema } from '@/lib/validation';

export async function GET() {
  const session = await getAdminSession();
  if (!session.adminId) return NextResponse.json({ error: 'Не авторизовано.' }, { status: 401 });

  const locations = await prisma.location.findMany({
    include: { directions: { include: { direction: true } }, trainer: true },
    orderBy: { createdAt: 'desc' }
  });
  return NextResponse.json({ data: locations });
}

export async function POST(req: NextRequest) {
  const session = await getAdminSession();
  if (!session.adminId) return NextResponse.json({ error: 'Не авторизовано.' }, { status: 401 });

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Некоректний запит.' }, { status: 400 });
  }

  const parsed = locationSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message || 'Перевірте форму.' }, { status: 400 });
  }

  const { directionIds, district, trainerId, trainerName, photoUrl, ...rest } = parsed.data;

  try {
    const location = await prisma.location.create({
      data: {
        ...rest,
        district: district || undefined,
        trainerId: trainerId || undefined,
        trainerName: trainerName || undefined,
        photoUrl: photoUrl || undefined,
        directions: { create: directionIds.map((directionId) => ({ directionId })) }
      }
    });
    return NextResponse.json({ data: location }, { status: 201 });
  } catch (err) {
    console.error('POST /api/admin/locations failed', err);
    return NextResponse.json({ error: 'Не вдалося створити філію.' }, { status: 500 });
  }
}
