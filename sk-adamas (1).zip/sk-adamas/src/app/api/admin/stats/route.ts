import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getAdminSession } from '@/lib/session';

export async function GET() {
  const session = await getAdminSession();
  if (!session.adminId) {
    return NextResponse.json({ error: 'Не авторизовано.' }, { status: 401 });
  }

  try {
    const [totalSignups, newSignups, totalLocations, totalSchedule, totalTrainers, recentSignups] =
      await Promise.all([
        prisma.signup.count(),
        prisma.signup.count({ where: { status: 'NEW' } }),
        prisma.location.count({ where: { active: true } }),
        prisma.schedule.count({ where: { active: true } }),
        prisma.trainer.count({ where: { active: true } }),
        prisma.signup.findMany({
          orderBy: { createdAt: 'desc' },
          take: 10,
          include: { direction: true, location: true }
        })
      ]);

    return NextResponse.json({
      data: { totalSignups, newSignups, totalLocations, totalSchedule, totalTrainers, recentSignups }
    });
  } catch (err) {
    console.error('GET /api/admin/stats failed', err);
    return NextResponse.json({ error: 'Не вдалося завантажити статистику.' }, { status: 500 });
  }
}
