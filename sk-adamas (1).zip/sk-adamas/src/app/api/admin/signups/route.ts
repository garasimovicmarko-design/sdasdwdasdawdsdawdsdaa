import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getAdminSession } from '@/lib/session';
import { SignupStatus } from '@prisma/client';

export async function GET(req: NextRequest) {
  const session = await getAdminSession();
  if (!session.adminId) return NextResponse.json({ error: 'Не авторизовано.' }, { status: 401 });

  const { searchParams } = new URL(req.url);
  const status = searchParams.get('status') as SignupStatus | null;
  const q = searchParams.get('q');

  const signups = await prisma.signup.findMany({
    where: {
      ...(status ? { status } : {}),
      ...(q
        ? {
            OR: [
              { childName: { contains: q, mode: 'insensitive' } },
              { contactName: { contains: q, mode: 'insensitive' } },
              { contactPhone: { contains: q, mode: 'insensitive' } }
            ]
          }
        : {})
    },
    include: { direction: true, location: true, trainingGroup: true },
    orderBy: { createdAt: 'desc' }
  });

  return NextResponse.json({ data: signups });
}
