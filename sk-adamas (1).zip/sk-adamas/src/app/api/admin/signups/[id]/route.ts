import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getAdminSession } from '@/lib/session';
import { z } from 'zod';

const updateSchema = z.object({
  status: z.enum(['NEW', 'CONTACTED', 'CONFIRMED', 'COMPLETED', 'CANCELLED']).optional(),
  internalNote: z.string().max(2000).optional()
});

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getAdminSession();
  if (!session.adminId) return NextResponse.json({ error: 'Не авторизовано.' }, { status: 401 });

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: 'Некоректний запит.' }, { status: 400 });
  }

  const parsed = updateSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: 'Перевірте дані.' }, { status: 400 });
  }

  try {
    const signup = await prisma.signup.update({ where: { id: params.id }, data: parsed.data });
    return NextResponse.json({ data: signup });
  } catch (err) {
    console.error('PATCH /api/admin/signups/[id] failed', err);
    return NextResponse.json({ error: 'Не вдалося оновити заявку.' }, { status: 500 });
  }
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getAdminSession();
  if (!session.adminId) return NextResponse.json({ error: 'Не авторизовано.' }, { status: 401 });

  try {
    await prisma.signup.delete({ where: { id: params.id } });
    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error('DELETE /api/admin/signups/[id] failed', err);
    return NextResponse.json({ error: 'Не вдалося видалити заявку.' }, { status: 500 });
  }
}
