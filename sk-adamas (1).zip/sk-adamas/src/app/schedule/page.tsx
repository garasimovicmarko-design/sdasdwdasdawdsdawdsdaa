import type { Metadata } from 'next';
import Link from 'next/link';
import { prisma } from '@/lib/prisma';

export const metadata: Metadata = { title: 'Розклад тренувань' };
export const revalidate = 120;

const weekdayLabels: Record<string, string> = {
  MON: 'Понеділок', TUE: 'Вівторок', WED: 'Середа', THU: 'Четвер', FRI: "П'ятниця", SAT: 'Субота', SUN: 'Неділя'
};
const weekdayOrder = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];

export default async function SchedulePage() {
  const schedules = await prisma.schedule.findMany({
    where: { active: true },
    include: { location: true, direction: true, trainer: true },
    orderBy: [{ weekday: 'asc' }, { startTime: 'asc' }]
  });

  const grouped = weekdayOrder.map((day) => ({
    day,
    items: schedules.filter((s) => s.weekday === day)
  }));

  return (
    <div className="container-adamas py-12">
      <h1 className="font-display text-3xl font-bold">Розклад тренувань</h1>
      <p className="mt-2 text-gray-600">
        Розклад формується адміністрацією клубу для кожної філії окремо. Оберіть свій зал на сторінці{' '}
        <Link href="/locations" className="text-adamas-red underline">філій</Link>, щоб побачити розклад саме там.
      </p>

      {schedules.length === 0 ? (
        <p className="mt-10 rounded-md bg-gray-50 px-4 py-6 text-center text-gray-500">
          Розклад ще наповнюється адміністрацією. Зателефонуйте нам, щоб дізнатися актуальний час тренувань.
        </p>
      ) : (
        <div className="mt-8 space-y-8">
          {grouped
            .filter((g) => g.items.length > 0)
            .map((g) => (
              <section key={g.day}>
                <h2 className="font-display text-xl font-semibold">{weekdayLabels[g.day]}</h2>
                <div className="mt-3 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  {g.items.map((s) => (
                    <div key={s.id} className="card">
                      <p className="font-semibold">{s.startTime}–{s.endTime}</p>
                      <p className="mt-1 text-sm text-gray-600">{s.direction.name}</p>
                      <p className="mt-1 text-sm text-gray-600">{s.location.name}, {s.location.address}</p>
                      {s.trainer && <p className="mt-1 text-sm text-gray-500">Тренер: {s.trainer.name}</p>}
                      <Link href={`/signup?locationId=${s.locationId}&directionId=${s.directionId}`} className="btn-primary mt-3 w-full text-center text-sm">
                        Записатися
                      </Link>
                    </div>
                  ))}
                </div>
              </section>
            ))}
        </div>
      )}
    </div>
  );
}
