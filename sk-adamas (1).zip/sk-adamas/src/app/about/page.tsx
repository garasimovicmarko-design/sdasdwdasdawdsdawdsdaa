import type { Metadata } from 'next';
import { prisma } from '@/lib/prisma';

export const metadata: Metadata = { title: 'Про клуб' };
export const revalidate = 300;

export default async function AboutPage() {
  const settings = await prisma.siteSettings.findUnique({ where: { id: 'singleton' } });

  return (
    <div className="container-adamas py-12">
      <h1 className="font-display text-3xl font-bold">Про клуб SK ADAMAS</h1>
      <div className="prose mt-6 max-w-2xl text-gray-700">
        <p>{settings?.aboutText}</p>
        <p>
          Наші спортсмени беруть активну участь в обласних, національних та міжнародних змаганнях,
          відвідують літні та зимові навчально-тренувальні збори та проходять атестації на пояси.
        </p>
        <p>
          Серед вихованців клубу є чемпіони та призери чемпіонатів Європи та Світу, а також члени
          збірної команди України.
        </p>
        <p>
          Тренування проводять кваліфіковані та мотивовані тренери, які працюють на результат.
          Клуб має багато відділень у Івано-Франківську, щоб люди могли підібрати зручне місце та
          час тренувань.
        </p>
      </div>
    </div>
  );
}
