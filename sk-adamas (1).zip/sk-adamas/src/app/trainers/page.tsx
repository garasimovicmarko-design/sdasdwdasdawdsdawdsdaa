import type { Metadata } from 'next';
import { prisma } from '@/lib/prisma';

export const metadata: Metadata = { title: 'Тренери' };
export const revalidate = 300;

export default async function TrainersPage() {
  const trainers = await prisma.trainer.findMany({
    where: { active: true },
    include: { locations: { select: { id: true, name: true } } },
    orderBy: { name: 'asc' }
  });

  return (
    <div className="container-adamas py-12">
      <h1 className="font-display text-3xl font-bold">Тренери</h1>
      <div className="mt-8 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {trainers.map((t) => (
          <div key={t.id} className="card">
            <p className="font-display text-lg font-semibold">{t.name}</p>
            {t.specialization && <p className="mt-1 text-sm text-gray-600">{t.specialization}</p>}
            {t.phone && <a href={`tel:${t.phone.replace(/\s|\(|\)/g, '')}`} className="mt-2 block text-sm text-adamas-red">{t.phone}</a>}
            {t.locations.length > 0 && (
              <p className="mt-2 text-xs text-gray-500">Філії: {t.locations.map((l) => l.name).join(', ')}</p>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
