import type { Metadata } from 'next';
import Link from 'next/link';
import { prisma } from '@/lib/prisma';

export const metadata: Metadata = {
  title: 'Тхеквондо в Івано-Франківську',
  description: 'Секція тхеквондо SK ADAMAS для дітей та дорослих від 6 років у Івано-Франківську.'
};
export const revalidate = 300;

export default async function TaekwondoPage() {
  const direction = await prisma.direction.findUnique({ where: { slug: 'taekwondo' } });

  return (
    <div className="container-adamas py-12">
      <h1 className="font-display text-3xl font-bold">Тхеквондо</h1>
      <p className="mt-4 max-w-2xl text-gray-600">
        {direction?.description || 'Традиційне бойове мистецтво для дітей та дорослих.'}
      </p>
      <p className="mt-2 text-gray-600">Вік: від {direction?.minAge ?? 6} років.</p>
      <div className="mt-6 flex gap-3">
        <Link href={`/signup?directionId=${direction?.id ?? ''}`} className="btn-primary">Записатися</Link>
        <Link href="/locations?direction=taekwondo" className="btn-secondary">Знайти зал</Link>
      </div>
    </div>
  );
}
