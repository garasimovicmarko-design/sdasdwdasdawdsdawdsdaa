import type { Metadata } from 'next';
import Link from 'next/link';
import { prisma } from '@/lib/prisma';

export const metadata: Metadata = { title: 'Напрямки' };
export const revalidate = 300;

export default async function DirectionsPage() {
  const directions = await prisma.direction.findMany({ where: { active: true }, orderBy: { sortOrder: 'asc' } });

  return (
    <div className="container-adamas py-12">
      <h1 className="font-display text-3xl font-bold">Напрямки</h1>
      <div className="mt-8 grid grid-cols-1 gap-6 sm:grid-cols-2">
        {directions.map((d) => (
          <Link key={d.id} href={`/directions/${d.slug}`} className="card block">
            <p className="font-display text-2xl font-semibold">{d.name}</p>
            <p className="mt-2 text-gray-600">{d.description}</p>
            <p className="mt-3 text-sm font-medium text-adamas-red">Від {d.minAge} років →</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
