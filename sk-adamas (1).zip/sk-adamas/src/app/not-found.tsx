import Link from 'next/link';

export default function NotFound() {
  return (
    <div className="container-adamas flex min-h-[60vh] flex-col items-center justify-center text-center">
      <p className="font-display text-6xl font-bold text-adamas-red">404</p>
      <h1 className="mt-4 font-display text-2xl font-bold">Сторінку не знайдено</h1>
      <p className="mt-2 max-w-md text-gray-600">
        Схоже, такої сторінки не існує або вона була переміщена. Спробуйте перейти на головну або
        знайти потрібну філію в списку.
      </p>
      <div className="mt-6 flex gap-3">
        <Link href="/" className="btn-primary">На головну</Link>
        <Link href="/locations" className="btn-secondary">Всі філії</Link>
      </div>
    </div>
  );
}
