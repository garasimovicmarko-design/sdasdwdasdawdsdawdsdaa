'use client';

import { useEffect } from 'react';

export default function GlobalError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => {
    console.error('Unhandled application error:', error);
  }, [error]);

  return (
    <html lang="uk">
      <body className="flex min-h-screen flex-col items-center justify-center bg-white text-center">
        <div className="container-adamas">
          <p className="font-display text-6xl font-bold text-adamas-red">500</p>
          <h1 className="mt-4 font-display text-2xl font-bold">Щось пішло не так</h1>
          <p className="mt-2 max-w-md text-gray-600">
            На нашому боці сталася технічна помилка. Спробуйте оновити сторінку, або зателефонуйте
            нам напряму, якщо ви намагалися записатися на тренування.
          </p>
          <button onClick={reset} className="btn-primary mt-6">Спробувати ще раз</button>
        </div>
      </body>
    </html>
  );
}
