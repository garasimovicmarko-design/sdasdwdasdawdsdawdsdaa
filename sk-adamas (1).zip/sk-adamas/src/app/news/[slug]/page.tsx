import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { prisma } from '@/lib/prisma';

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const article = await prisma.news.findUnique({ where: { slug: params.slug } });
  if (!article) return { title: 'Новину не знайдено' };
  return { title: article.title, description: article.excerpt || undefined };
}

export default async function NewsArticlePage({ params }: { params: { slug: string } }) {
  const article = await prisma.news.findUnique({ where: { slug: params.slug } });
  if (!article || !article.published) notFound();

  return (
    <article className="container-adamas py-12">
      <h1 className="font-display text-3xl font-bold">{article.title}</h1>
      <div className="prose mt-6 max-w-2xl whitespace-pre-wrap text-gray-700">{article.content}</div>
    </article>
  );
}
