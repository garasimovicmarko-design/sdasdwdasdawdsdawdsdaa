import type { Metadata } from 'next';
import Link from 'next/link';
import { prisma } from '@/lib/prisma';

export const metadata: Metadata = { title: 'Новини' };
export const revalidate = 120;

export default async function NewsPage() {
  const news = await prisma.news.findMany({
    where: { published: true },
    orderBy: { publishedAt: 'desc' }
  });

  return (
    <div className="container-adamas py-12">
      <h1 className="font-display text-3xl font-bold">Новини</h1>
      {news.length === 0 ? (
        <p className="mt-8 text-gray-500">Новин поки немає. Стежте за оновленнями в Instagram клубу.</p>
      ) : (
        <div className="mt-8 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {news.map((n) => (
            <Link key={n.id} href={`/news/${n.slug}`} className="card block">
              <p className="font-display font-semibold">{n.title}</p>
              {n.excerpt && <p className="mt-2 text-sm text-gray-600">{n.excerpt}</p>}
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
