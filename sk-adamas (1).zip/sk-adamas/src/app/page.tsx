import Link from 'next/link';
import { prisma } from '@/lib/prisma';

export const revalidate = 300;

export default async function HomePage() {
  const [locationsCount, directions, recentLocations] = await Promise.all([
    prisma.location.count({ where: { active: true, hidden: false } }),
    prisma.direction.findMany({ where: { active: true }, orderBy: { sortOrder: 'asc' } }),
    prisma.location.findMany({
      where: { active: true, hidden: false },
      take: 3,
      orderBy: { createdAt: 'desc' }
    })
  ]);

  const advantages = [
    { title: `${locationsCount} філій`, text: 'Зручне розташування залів по всьому Івано-Франківську та області.' },
    { title: 'Тренери-професіонали', text: 'Кваліфіковані тренери, які працюють на результат.' },
    { title: 'Змагання', text: 'Обласні, національні та міжнародні змагання для наших спортсменів.' },
    { title: 'Навчально-тренувальні збори', text: 'Літні та зимові збори для поглибленої підготовки.' },
    { title: 'Атестація на пояси', text: 'Прозора система атестацій та зростання рівня майстерності.' },
    { title: 'Збірна України', text: 'Серед вихованців клубу є члени збірної команди України.' }
  ];

  return (
    <>
      <section className="relative overflow-hidden bg-adamas-black text-white">
        <div className="container-adamas relative z-10 flex flex-col items-start gap-6 py-24 sm:py-32">
          <p className="font-display text-sm uppercase tracking-[0.3em] text-adamas-gold">
            Тхеквондо • Кікбоксинг ISKA
          </p>
          <h1 className="font-display text-4xl font-bold leading-tight sm:text-6xl">
            SK ADAMAS
          </h1>
          <p className="max-w-xl text-lg text-gray-300">
            «Разом до майбутніх перемог» — спортивний клуб для дітей та дорослих. Тренування,
            змагання, збори та розвиток спортивного характеру.
          </p>
          <div className="flex flex-col gap-3 sm:flex-row">
            <Link href="/signup" className="btn-primary">Записатися на тренування</Link>
            <Link href="/locations" className="btn-secondary border-white text-white hover:bg-white hover:text-adamas-black">
              Знайти свій зал
            </Link>
          </div>
        </div>
      </section>

      <section className="container-adamas py-16">
        <h2 className="font-display text-2xl font-bold sm:text-3xl">Чому SK ADAMAS</h2>
        <div className="mt-8 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {advantages.map((a) => (
            <div key={a.title} className="card">
              <p className="font-display text-lg font-semibold">{a.title}</p>
              <p className="mt-2 text-sm text-gray-600">{a.text}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="bg-gray-50 py-16">
        <div className="container-adamas">
          <h2 className="font-display text-2xl font-bold sm:text-3xl">Напрямки</h2>
          <div className="mt-8 grid grid-cols-1 gap-6 sm:grid-cols-2">
            {directions.map((d) => (
              <Link key={d.id} href={`/directions/${d.slug}`} className="card block">
                <p className="font-display text-xl font-semibold">{d.name}</p>
                <p className="mt-2 text-sm text-gray-600">{d.description}</p>
                <p className="mt-3 text-sm font-medium text-adamas-red">Від {d.minAge} років →</p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="container-adamas py-16">
        <div className="flex items-center justify-between">
          <h2 className="font-display text-2xl font-bold sm:text-3xl">Наші філії</h2>
          <Link href="/locations" className="text-sm font-semibold text-adamas-red">Всі філії →</Link>
        </div>
        <div className="mt-8 grid grid-cols-1 gap-6 sm:grid-cols-3">
          {recentLocations.map((loc) => (
            <div key={loc.id} className="card">
              <p className="font-display font-semibold">{loc.name}</p>
              <p className="mt-1 text-sm text-gray-600">{loc.address}</p>
              <Link href={`/locations/${loc.id}`} className="mt-3 inline-block text-sm font-semibold text-adamas-red">
                Детальніше →
              </Link>
            </div>
          ))}
        </div>
      </section>

      <section className="bg-adamas-black py-16 text-center text-white">
        <div className="container-adamas">
          <h2 className="font-display text-2xl font-bold sm:text-3xl">Готові розпочати?</h2>
          <p className="mx-auto mt-3 max-w-xl text-gray-300">
            Оберіть зручний зал та запишіться на перше тренування вже сьогодні.
          </p>
          <Link href="/signup" className="btn-primary mt-6 inline-flex">Записатися на тренування</Link>
        </div>
      </section>
    </>
  );
}
