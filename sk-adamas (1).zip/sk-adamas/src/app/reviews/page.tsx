import type { Metadata } from 'next';
import { prisma } from '@/lib/prisma';
import ReviewForm from '@/components/ReviewForm';

export const metadata: Metadata = { title: 'Відгуки' };
export const revalidate = 120;

export default async function ReviewsPage() {
  const reviews = await prisma.review.findMany({
    where: { status: 'APPROVED' },
    orderBy: { createdAt: 'desc' }
  });

  return (
    <div className="container-adamas py-12">
      <h1 className="font-display text-3xl font-bold">Відгуки</h1>

      <div className="mt-8 grid grid-cols-1 gap-6 sm:grid-cols-2">
        {reviews.map((r) => (
          <div key={r.id} className="card">
            <p className="font-semibold">{r.name}</p>
            <p className="mt-1 text-sm text-adamas-gold">{'★'.repeat(r.rating)}{'☆'.repeat(5 - r.rating)}</p>
            <p className="mt-2 text-sm text-gray-600">{r.text}</p>
          </div>
        ))}
        {reviews.length === 0 && <p className="text-gray-500">Відгуків поки немає — станьте першими!</p>}
      </div>

      <div className="mt-12 max-w-lg">
        <h2 className="font-display text-xl font-semibold">Залишити відгук</h2>
        <p className="mt-1 text-sm text-gray-500">Відгук з'явиться на сайті після модерації адміністрацією.</p>
        <ReviewForm />
      </div>
    </div>
  );
}
