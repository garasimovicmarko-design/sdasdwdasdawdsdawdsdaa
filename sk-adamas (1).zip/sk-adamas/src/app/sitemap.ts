import type { MetadataRoute } from 'next';
import { prisma } from '@/lib/prisma';

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://adamas.example.com';

  const staticRoutes = [
    '', '/about', '/directions', '/directions/taekwondo', '/directions/kickboxing',
    '/locations', '/trainers', '/schedule', '/achievements', '/gallery', '/news',
    '/reviews', '/contact', '/signup', '/privacy', '/terms'
  ].map((path) => ({ url: `${siteUrl}${path}`, lastModified: new Date() }));

  const [locations, news] = await Promise.all([
    prisma.location.findMany({ where: { active: true, hidden: false }, select: { id: true, updatedAt: true } }),
    prisma.news.findMany({ where: { published: true }, select: { slug: true, updatedAt: true } })
  ]);

  const locationRoutes = locations.map((l) => ({
    url: `${siteUrl}/locations/${l.id}`,
    lastModified: l.updatedAt
  }));

  const newsRoutes = news.map((n) => ({
    url: `${siteUrl}/news/${n.slug}`,
    lastModified: n.updatedAt
  }));

  return [...staticRoutes, ...locationRoutes, ...newsRoutes];
}
