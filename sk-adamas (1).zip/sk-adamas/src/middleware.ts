import { NextRequest, NextResponse } from 'next/server';

// We can't use Prisma/iron-session's Node APIs directly inside edge middleware
// reliably in every deployment target, so this does a lightweight cookie
// presence check as a first line of defense. The real authorization check
// (session validity, admin.active) happens server-side in every /api/admin/*
// route and in each admin page's server component — this middleware only
// stops unauthenticated users from ever reaching the admin UI shell.
const COOKIE_NAME = 'adamas_admin_session';

export function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  if (pathname.startsWith('/admin') && pathname !== '/admin/login') {
    const cookie = req.cookies.get(COOKIE_NAME);
    if (!cookie) {
      const loginUrl = new URL('/admin/login', req.url);
      return NextResponse.redirect(loginUrl);
    }
  }

  return NextResponse.next();
}

export const config = {
  matcher: ['/admin/:path*']
};
