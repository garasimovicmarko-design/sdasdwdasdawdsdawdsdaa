import { PrismaClient, Weekday } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

const trainers = [
  { key: 'vorokh', name: 'Ворох Василь Володимирович', phone: '+38 (095) 450-49-00' },
  { key: 'klyuba', name: 'Клюба Андрій Андрійович', phone: '+38 (099) 379-60-11' },
  { key: 'demianyuk', name: "Дем'янюк Анна Євгенівна", phone: '+38 (099) 263-28-72' },
  { key: 'onyshchenko', name: 'Онищенко Андрій Володимирович', phone: '+38 (050) 623-61-59' },
  { key: 'barchuk', name: 'Барчук Владислав Ростиславович', phone: '+38 (066) 204-03-36' },
  { key: 'greshko', name: 'Грешко Роман Володимирович', phone: '+38 (067) 880-01-04' }
];

const locationsRaw = [
  { name: 'Ліцей №18', address: 'вулиця Тролейбусна, 7', phone: '+38 (095) 450-49-00', trainer: 'vorokh' },
  { name: 'Початкова школа ім. Софії Русової', address: 'вулиця Василіянок, 28', phone: '+38 (095) 450-49-00', trainer: 'vorokh' },
  { name: 'Школа-садок №6', address: 'вулиця Пасічна, 3', phone: '+38 (099) 379-60-11', trainer: 'klyuba' },
  { name: 'Ліцей №5', address: 'вулиця Івана Франка, 19', phone: '+38 (099) 379-60-11', trainer: 'klyuba' },
  { name: 'Спортклуб «Прайм»', address: 'вулиця Софрона Мудрого (Гарбарська), 22', phone: '+38 (099) 379-60-11', trainer: 'klyuba' },
  { name: 'Ліцей №17', address: 'вулиця Набережна ім. Василя Стефаника, 16а', phone: '+38 (099) 263-28-72', trainer: 'demianyuk' },
  { name: 'Ліцей №7', address: 'вулиця Грушевського, 16', phone: '+38 (099) 263-28-72', trainer: 'demianyuk' },
  { name: 'Ліцей №19', address: 'вулиця Гната Хоткевича, 56', phone: '+38 (050) 623-61-59', trainer: 'onyshchenko' },
  { name: 'Угринівський ліцей', address: 'вулиця Галицька, 2', phone: '+38 (050) 623-61-59', trainer: 'onyshchenko' },
  { name: 'Загвіздянська школа', address: 'с. Загвіздя, вул. Підгірка, 2', phone: '+38 (050) 623-61-59', trainer: 'onyshchenko' },
  { name: 'Ліцей №24', address: 'вулиця Хіміків, 1', phone: '+38 (066) 204-03-36', trainer: 'barchuk' },
  { name: 'Початкова школа №9', address: 'вулиця Гетьмана Мазепи, 169', phone: '+38 (066) 204-03-36', trainer: 'barchuk' },
  { name: 'Ліцей №20', address: 'вулиця Гоголя, 10', phone: '+38 (066) 204-03-36', trainer: 'barchuk' },
  { name: 'Початкова школа №8', address: 'вулиця Коломийська, 9', phone: '+38 (066) 204-03-36', trainer: 'barchuk' },
  { name: 'Ліцей №13', address: 'вулиця Галицька, 65', phone: '+38 (067) 880-01-04', trainer: 'greshko' },
  { name: 'Ліцей №1', address: 'вулиця Довга, 37', phone: '+38 (067) 880-01-04', trainer: 'greshko' },
  { name: 'Початкова Католицька школа св. Василія Великого', address: 'вулиця Василіянок, 17', phone: '+38 (067) 880-01-04', trainer: 'greshko' },
  { name: 'Початкова школа Пасічнянська', address: 'вулиця Пасічна, 3', phone: '+38 (067) 880-01-04', trainer: 'greshko' },
  { name: 'ВПУ №13', address: 'вулиця Пасічна, 10а', phone: '+38 (067) 880-01-04', trainer: 'greshko' }
];

async function main() {
  console.log('Seeding directions...');
  const taekwondo = await prisma.direction.upsert({
    where: { slug: 'taekwondo' },
    update: {},
    create: {
      slug: 'taekwondo',
      name: 'Тхеквондо',
      shortName: 'Тхеквондо',
      description: 'Традиційне бойове мистецтво, дисципліна, атестація на пояси, участь у змаганнях.',
      minAge: 6,
      sortOrder: 1
    }
  });

  const kickboxing = await prisma.direction.upsert({
    where: { slug: 'kickboxing' },
    update: {},
    create: {
      slug: 'kickboxing',
      name: 'Кікбоксинг ISKA',
      shortName: 'Кікбоксинг',
      description: 'Кікбоксинг за версією ISKA — сила, витривалість та змагальна практика.',
      minAge: 6,
      sortOrder: 2
    }
  });

  console.log('Seeding trainers...');
  const trainerMap: Record<string, string> = {};
  for (const t of trainers) {
    const created = await prisma.trainer.create({
      data: {
        name: t.name,
        phone: t.phone,
        specialization: 'Тхеквондо / Кікбоксинг ISKA',
        active: true
      }
    });
    trainerMap[t.key] = created.id;
  }

  console.log('Seeding locations...');
  for (const loc of locationsRaw) {
    const trainerId = trainerMap[loc.trainer];
    const trainerName = trainers.find((t) => t.key === loc.trainer)!.name;
    await prisma.location.create({
      data: {
        name: loc.name,
        address: loc.address,
        phone: loc.phone,
        trainerName,
        trainerId,
        minAge: 6,
        active: true,
        directions: {
          create: [{ directionId: taekwondo.id }, { directionId: kickboxing.id }]
        }
      }
    });
  }

  console.log('Seeding site settings...');
  await prisma.siteSettings.upsert({
    where: { id: 'singleton' },
    update: {},
    create: {
      id: 'singleton',
      siteName: 'SK ADAMAS',
      instagramUrl: 'https://www.instagram.com/adamas_ua',
      heroTitle: 'Разом до майбутніх перемог',
      heroSubtitle:
        'Спортивний клуб для дітей та дорослих. Тренування, змагання, збори та розвиток спортивного характеру.',
      aboutText:
        '«SK ADAMAS» проводить набір у групи з тхеквондо та кікбоксингу ISKA віком від 6 років у Івано-Франківську та області.'
    }
  });

  console.log('Seeding gallery with club photos...');
  const galleryPhotos = [
    { imageUrl: '/images/training-lineup.png', category: 'training', caption: 'Тренування з тхеквондо', sortOrder: 1 },
    { imageUrl: '/images/kickboxing-sparring.png', category: 'competition', caption: 'Спаринг на змаганнях з кікбоксингу', sortOrder: 2 },
    { imageUrl: '/images/young-fighter-coach.png', category: 'training', caption: 'Юний спортсмен з тренером перед боєм', sortOrder: 3 },
    { imageUrl: '/images/team-flag.png', category: 'achievements', caption: 'Команда клубу на міжнародних змаганнях', sortOrder: 4 },
    { imageUrl: '/images/champions-belts.png', category: 'achievements', caption: 'Чемпіонські пояси ISKA', sortOrder: 5 },
    { imageUrl: '/images/iska-ukraine-championship.png', category: 'competition', caption: 'Чемпіонат України ISKA', sortOrder: 6 },
    { imageUrl: '/images/team-medals-italy.png', category: 'achievements', caption: 'Спортсмени клубу з нагородами', sortOrder: 7 }
  ];
  for (const photo of galleryPhotos) {
    await prisma.galleryItem.create({ data: photo });
  }

  const adminPasswordEnv = process.env.SEED_ADMIN_PASSWORD;
  if (!adminPasswordEnv) {
    console.warn(
      'SEED_ADMIN_PASSWORD not set — skipping admin user creation. Set it in .env and re-run `npm run db:seed` to create the first admin.'
    );
  } else {
    const passwordHash = await bcrypt.hash(adminPasswordEnv, 12);
    await prisma.admin.upsert({
      where: { email: process.env.SEED_ADMIN_EMAIL || 'admin@adamas.local' },
      update: {},
      create: {
        email: process.env.SEED_ADMIN_EMAIL || 'admin@adamas.local',
        passwordHash,
        name: 'Адміністратор'
      }
    });
    console.log('Admin user created.');
  }

  console.log('Seed complete: 19 locations, 6 trainers, 2 directions.');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
