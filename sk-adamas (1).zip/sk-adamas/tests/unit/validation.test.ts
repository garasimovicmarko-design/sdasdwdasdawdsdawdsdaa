import { describe, it, expect } from 'vitest';
import { signupSchema, loginSchema, locationSchema } from '@/lib/validation';

describe('signupSchema', () => {
  const validBase = {
    childName: 'Іван Іванов',
    age: 10,
    contactName: 'Марія Іванова',
    contactPhone: '+380991234567',
    consentPolicy: true as const
  };

  it('accepts a valid minor signup and marks isMinor true', () => {
    const result = signupSchema.safeParse(validBase);
    expect(result.success).toBe(true);
    if (result.success) {
      expect(result.data.isMinor).toBe(true);
    }
  });

  it('marks isMinor false for an adult', () => {
    const result = signupSchema.safeParse({ ...validBase, age: 25 });
    expect(result.success).toBe(true);
    if (result.success) {
      expect(result.data.isMinor).toBe(false);
    }
  });

  it('rejects when consentPolicy is missing', () => {
    const { consentPolicy, ...rest } = validBase;
    const result = signupSchema.safeParse(rest);
    expect(result.success).toBe(false);
  });

  it('rejects an invalid phone number', () => {
    const result = signupSchema.safeParse({ ...validBase, contactPhone: 'abc' });
    expect(result.success).toBe(false);
  });

  it('rejects a name shorter than 2 characters', () => {
    const result = signupSchema.safeParse({ ...validBase, childName: 'A' });
    expect(result.success).toBe(false);
  });

  it('rejects age above 99', () => {
    const result = signupSchema.safeParse({ ...validBase, age: 150 });
    expect(result.success).toBe(false);
  });

  it('coerces a numeric-string age', () => {
    const result = signupSchema.safeParse({ ...validBase, age: '12' as unknown as number });
    expect(result.success).toBe(true);
  });
});

describe('loginSchema', () => {
  it('accepts a valid email/password pair', () => {
    expect(loginSchema.safeParse({ email: 'admin@adamas.local', password: 'longenoughpassword' }).success).toBe(true);
  });

  it('rejects an invalid email', () => {
    expect(loginSchema.safeParse({ email: 'not-an-email', password: 'longenoughpassword' }).success).toBe(false);
  });

  it('rejects a too-short password', () => {
    expect(loginSchema.safeParse({ email: 'admin@adamas.local', password: 'short' }).success).toBe(false);
  });
});

describe('locationSchema', () => {
  it('accepts a minimal valid location', () => {
    const result = locationSchema.safeParse({
      name: 'Ліцей №1',
      address: 'вулиця Довга, 37',
      phone: '+38 (067) 880-01-04'
    });
    expect(result.success).toBe(true);
  });

  it('rejects a location with no address', () => {
    const result = locationSchema.safeParse({ name: 'Ліцей №1', address: '', phone: '+38 (067) 880-01-04' });
    expect(result.success).toBe(false);
  });
});
