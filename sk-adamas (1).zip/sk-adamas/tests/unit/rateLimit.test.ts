import { describe, it, expect } from 'vitest';
import { rateLimit } from '@/lib/rateLimit';

describe('rateLimit', () => {
  it('allows requests under the limit', () => {
    const key = `test-${Date.now()}-a`;
    const r1 = rateLimit(key, 3, 1000);
    const r2 = rateLimit(key, 3, 1000);
    const r3 = rateLimit(key, 3, 1000);
    expect(r1.allowed).toBe(true);
    expect(r2.allowed).toBe(true);
    expect(r3.allowed).toBe(true);
  });

  it('blocks requests over the limit within the window', () => {
    const key = `test-${Date.now()}-b`;
    rateLimit(key, 2, 1000);
    rateLimit(key, 2, 1000);
    const r3 = rateLimit(key, 2, 1000);
    expect(r3.allowed).toBe(false);
    expect(r3.retryAfterMs).toBeGreaterThan(0);
  });

  it('tracks separate keys independently', () => {
    const keyA = `test-${Date.now()}-c1`;
    const keyB = `test-${Date.now()}-c2`;
    rateLimit(keyA, 1, 1000);
    const rA = rateLimit(keyA, 1, 1000);
    const rB = rateLimit(keyB, 1, 1000);
    expect(rA.allowed).toBe(false);
    expect(rB.allowed).toBe(true);
  });
});
