import { test, expect } from '@playwright/test';

test('user can submit the signup form', async ({ page }) => {
  await page.goto('/signup');

  await page.getByLabel("Ім'я та прізвище учасника *").fill('Тестовий Учасник');
  await page.getByLabel('Вік *').fill('10');
  await page.getByLabel("Ім'я батька/матері або представника *").fill('Тестовий Представник');
  await page.getByLabel("Телефон для зв'язку *").fill('+380991234567');
  await page.getByLabel(/Я погоджуюся з/).check();

  await page.getByRole('button', { name: 'Відправити заявку' }).click();

  await expect(page.getByText('Дякуємо за заявку!')).toBeVisible({ timeout: 10_000 });
});

test('signup form shows validation errors when required fields are empty', async ({ page }) => {
  await page.goto('/signup');
  await page.getByRole('button', { name: 'Відправити заявку' }).click();
  await expect(page.getByText("Введіть ім'я та прізвище")).toBeVisible();
});
