import { test, expect } from '@playwright/test';

test('home page loads with hero and nav to locations', async ({ page }) => {
  await page.goto('/');
  await expect(page.getByRole('heading', { name: 'SK ADAMAS' })).toBeVisible();
  await page.getByRole('link', { name: 'Знайти свій зал' }).click();
  await expect(page).toHaveURL(/\/locations/);
  await expect(page.getByRole('heading', { name: 'Філії SK ADAMAS' })).toBeVisible();
});
