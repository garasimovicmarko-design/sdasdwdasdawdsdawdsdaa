import { test, expect } from '@playwright/test';

test('unauthenticated user is redirected away from admin dashboard', async ({ page }) => {
  await page.goto('/admin');
  await expect(page).toHaveURL(/\/admin\/login/);
});

test('unauthenticated user is redirected away from admin locations page', async ({ page }) => {
  await page.goto('/admin/locations');
  await expect(page).toHaveURL(/\/admin\/login/);
});

test('wrong admin credentials are rejected', async ({ page }) => {
  await page.goto('/admin/login');
  await page.getByLabel('Email').fill('nonexistent@adamas.local');
  await page.getByLabel('Пароль').fill('wrongpassword123');
  await page.getByRole('button', { name: 'Увійти' }).click();
  await expect(page.getByText('Невірний email або пароль.')).toBeVisible();
});
