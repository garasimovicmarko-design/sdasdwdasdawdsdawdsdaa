import { test, expect } from '@playwright/test';

test('user can open a location detail page from the list', async ({ page }) => {
  await page.goto('/locations');
  const firstDetails = page.getByRole('link', { name: 'Детальніше' }).first();
  await expect(firstDetails).toBeVisible();
  await firstDetails.click();
  await expect(page.getByRole('link', { name: 'Записатися на тренування' })).toBeVisible();
});
